define(function (require, exports, module) {
  require('./node_modules/brackets-inspection-gutters/dist/main')();
  require('./dist/main');
});

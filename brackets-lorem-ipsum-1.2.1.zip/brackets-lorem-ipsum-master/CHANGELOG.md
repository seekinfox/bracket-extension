# Changelog

## 1.2.1 (05/07/2017)
* Fix issue [#12](https://github.com/lkcampbell/brackets-lorem-ipsum/issues/12)

## 1.2.0 (04/16/2017)
* Added the `_orig[count]` option.

## 1.1.2 (04/09/2017)
* Two new preferences added: `brackets-lorem-ipsum.onLoremCommand` and
`brackets-lorem-ipsum.onNoCommand`.

## 1.1.1 (04/09/2017)
* The `_?` and `_help` option now display Lorem Ipsum help in a dialog
box inside of Brackets.

## 1.1.0 (04/04/2017)
* Changed default keyboard shortcut from `Tab` to `Ctrl-Shift-L` so
that this extension no longer conflicts with the
[Emmet Brackets extension](https://github.com/emmetio/brackets-emmet).
* Added customized key bindings.
